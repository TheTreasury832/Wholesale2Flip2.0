Run: pip install -r requirements.txt && streamlit run app_w2f.py
